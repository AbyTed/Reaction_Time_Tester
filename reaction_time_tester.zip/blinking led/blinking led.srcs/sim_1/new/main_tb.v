`timescale 1ns / 1ps

module main_tb();

    reg MCLK_tb;
    reg button1_tb;

    wire led_red_tb;
    wire led_green_tb;

    main uut (
        .MCLK(MCLK_tb),
        .button1(button1_tb),
        .led_red(led_red_tb),
        .led_green(led_green_tb)
    );

    // 100 MHz clock
    initial begin
        MCLK_tb = 1'b0;
        forever #5 MCLK_tb = ~MCLK_tb;
    end

    // Test
    initial begin
        button1_tb = 1'b0;

        // Wait
        #5;

        // Press button
        button1_tb = 1'b1;
        #20;

        // Release button
        button1_tb = 1'b0;

        // Let circuit run
        #1000000;
        
        // Press button
        button1_tb = 1'b1;
        #20;

        // Release button
        button1_tb = 1'b0;
        $finish;
    end

endmodule