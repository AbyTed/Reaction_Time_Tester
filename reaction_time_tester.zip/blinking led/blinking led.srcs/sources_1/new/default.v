`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/18/2026 12:41:48 AM
// Design Name: 
// Module Name: main
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module main(
input MCLK,
input button1,
output led_red,
output led_green);
    reg [31:0] count_clock = 32'd0;
    reg r_led_red = 1'b0;
    reg r_led_green = 1'b0;
    reg r_both_leds_blinking = 1'b0;
    reg [31:0] led_clock = 32'd1000000;
    
    
    always @(posedge MCLK)
    begin
        if (r_both_leds_blinking == 1'b0 && !button1 == 1'b1) begin
            if (count_clock < 32'd25000000) begin
                
                r_led_red <= 1'b0;
                r_led_green <= 1'b1;
            end    
            if (count_clock >= 32'd25000000 
                && count_clock <= 32'd50000000) begin
                
                r_led_red <= 1'b1;
                r_led_green <= 1'b0;
                $display("decent speed: ", count_clock);
            end
            if(count_clock > 32'd50000000) begin
                 r_both_leds_blinking <= 1'b1;
                 r_led_red <= 1'b1;
            end 
        end
        if (r_both_leds_blinking == 1'b1 && led_clock >= 32'd25000000) begin
            r_led_green <= ~r_led_green;
            r_led_red <= ~r_led_red;
            led_clock <= 32'd0;
        end else begin
            led_clock <= led_clock + 1;
        end
        
        $display("MCLK VALUE = %0d", led_clock);      
    end
    
    always @(posedge MCLK) begin
    
        count_clock <= count_clock + 1;
        
        
    end
    

    
    assign led_red = r_led_red;
    assign led_green = r_led_green;
    
endmodule
